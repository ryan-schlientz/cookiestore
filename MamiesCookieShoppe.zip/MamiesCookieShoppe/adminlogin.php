<?php
session_start();
require_once 'userheader.php';
require_once 'login.php';

if(isset($_POST['username']) && isset($_POST['pwd']))
{
$user = sanitizeString($_POST['username']);
$pass = sanitizeString($_POST['pwd']);

$query="SELECT * FROM admin WHERE username= '$user' AND pwd=PASSWORD('$pass')";
$result = mysql_query($query);
if(!$result) die ("Access Failed".mysql_error());
$rows = mysql_num_rows($result);

if($rows==1)
{
	$row=mysql_fetch_row($result);
	$_SESSION['admin']=$row[0];	
	adminhtml_header("Admin Log In");
	echo <<<_END
	<p>You have successfully logged into an admin account.</p>
	<p class="text">Here is where you can view daily summaries and alter information about the cookies sold.
			You may also choose to hide a cookie from display.</p>
			
_END;
	adminfoot();
}
else
{
	html_header("Admin Log In");
	echo <<<_END
	<p> Log in failed. Invalid admin username/password combination. Please try again. <a href="adminSignIn.php">Admin Log In</a></p>
_END;
	foot();
}
}
else
{
	adminDeny();
}
?>