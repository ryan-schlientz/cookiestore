<?php
/* The user is redirected to this page when they click sign up on the sign up page. This page makes sure
 * the information entered is harmless through the sanitizeString function.*/
session_start();
require_once 'login.php';
require_once 'userheader.php';
html_header("Register New User");

//enter the user into the customer table.

	if (isset($_POST['lastname'])) $last = sanitizeString($_POST['lastname']);
	if (isset($_POST['firstname'])) $first = sanitizeString($_POST['firstname']);
	if (isset($_POST['email'])) $email = sanitizeString($_POST['email']);
	if (isset($_POST['password'])) $user = sanitizeString($_POST['password']);

	$query="INSERT INTO customer (customerID, lastname, firstname,email,pwd)
	VALUES(NULL,'$last','$first','$email', PASSWORD('$user'))";
	$result=mysql_query($query);
	if($result==true)
	{
		echo "<p>Congratulations! You are now registered as $last, $first</p>";
		echo "<p>Click on sign in and explore our website.</p>";

	}
	else
	{
		echo "<p>That username has already been taken. Please try again.</p>";
	}


foot();
?>