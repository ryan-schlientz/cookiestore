<?php
session_start();

require_once 'userheader.php';
html_header("About Us");
echo <<<_END
<p class="text">Mamie's Cookie Shoppe began in 2011 and has been going strong ever since. 
		Ben and Amy Dowis started the company because of the numerous requests they received for their Christmas cookies. 
		They have always been dedicated to building the perfect cookie.
		Along with their children, they taste every cookie recipe until it is just right, so you can be sure that your cookie is always fantastic!
		If you are not completely satisfied, please feel free to make a suggestion so that we can continue our search for the perfect cookie.</p>
_END;
foot();
?>