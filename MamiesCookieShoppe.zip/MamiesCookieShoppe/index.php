<?php
session_start();
require_once 'userheader.php';
html_header("Index");
echo "<p> Welcome to Our Cookie Store. If you are searching for the best cookies in town, you are in the right place!</p>";
echo <<<_END
<div id="comslider_in_point_613207" align="center"></div><script type="text/javascript">var oCOMScript613207=document.createElement('script');oCOMScript613207.src="http://commondatastorage.googleapis.com/comslider/target/users/1429040438x19cf87d7a391da9bd0a0683a3edf9209/comslider.js?timestamp=1429042629";oCOMScript613207.type='text/javascript';document.getElementsByTagName("head").item(0).appendChild(oCOMScript613207);</script>
_END;
foot();
?>