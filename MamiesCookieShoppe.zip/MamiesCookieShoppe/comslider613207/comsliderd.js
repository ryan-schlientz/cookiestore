function comSlider613207() { 
var self = this; 
var g_HostRoot = "";
var g_TransitionTimeoutRef = null;
var g_CycleTimeout = 5;
var g_currFrame = 0;
var g_fontLoadJsRetries = 0;
var g_currDate = new Date(); var g_currTime = g_currDate.getTime();var g_microID = g_currTime + '-' + Math.floor((Math.random()*1000)+1); 
var g_InTransition = 0;var g_Navigation = 0;this.getCurrMicroID = function() { return g_microID; } 
this.comSLoadImgInFrame = function(frameid, src) 
{
     jqCS613207("#comSImg613207_"+frameid+" img").attr("src", src).load(function(){
         if (!this.complete || typeof this.naturalWidth == "undefined" || this.naturalWidth == 0)
         {
             //broken image
         }
     });
}
this.setNavStyle = function(id, background, color, border, type)
{
 if (background == "")
 {
     jqCS613207("#comSNavigation613207_"+id).css("background", "none");
 }
 else if (background == "transparent")
 {
     jqCS613207("#comSNavigation613207_"+id).css("background", "transparent");
 }
 else
 {
     jqCS613207("#comSNavigation613207_"+id).css("background", "#"+background);
 }
 jqCS613207("#comSNavigation613207_"+id).css("color", "#"+color);
 jqCS613207("#comSNavigation613207_"+id).css("border", border+"px solid #"+color);
 var margin = (-1)*border;
 jqCS613207("#comSNavigation613207_"+id).css("margin-top", margin+"px");
 jqCS613207("#comSNavigation613207_"+id).css("margin-left", margin+"px");
 if (type == 0)
 {
   jqCS613207("#comImgBullet613207_"+id).show();
   jqCS613207("#comImgBulletcurr613207_"+id).hide();
 }
 else
 {
   jqCS613207("#comImgBulletcurr613207_"+id).show();
   jqCS613207("#comImgBullet613207_"+id).hide();
 }
}
this.targetClearTimeouts = function()
{
 if (g_TransitionTimeoutRef != null)     { window.clearTimeout(g_TransitionTimeoutRef); g_TransitionTimeoutRef = null;}
}
this.getNextFrame = function()
{
 var ret = g_currFrame;
 ret++;
 if (ret == 3) {ret = 0;}
 return ret;
}
this.getPrevFrame = function()
{
 var ret = g_currFrame;
 ret--;
 if (ret < 0) {ret = (3-1);}
 return ret;
}
this.stopAll = function()
{
jqCS613207("#comSFrame613207_0").stop(true, true);
jqCS613207("#comSFrameSek613207_0").stop(true, true);
jqCS613207("#comSFrame613207_1").stop(true, true);
jqCS613207("#comSFrameSek613207_1").stop(true, true);
jqCS613207("#comSFrame613207_2").stop(true, true);
jqCS613207("#comSFrameSek613207_2").stop(true, true);
}
this.switchFrame = function()
{
     g_Navigation = 1;
     var currFrame=g_currFrame;
     g_currFrame = self.getNextFrame();
     self.switchFromToFrame(currFrame, g_currFrame);
}
 
this.switchFramePrev = function()
{
     g_Navigation = 0;
     var currFrame=g_currFrame;
     g_currFrame = self.getPrevFrame();
     self.switchFromToFrame(currFrame, g_currFrame);
}
 
this.switchToFrame = function(toFrame)
{
     if ((g_InTransition == 1) || (g_currFrame == toFrame))
     {
         if (g_currFrame == toFrame) { return false; }
         self.stopAll();
     }
     var currFrame=g_currFrame;
     g_currFrame=toFrame;
     if (currFrame < g_currFrame)
         g_Navigation = 0;
     else
         g_Navigation = 1;
     self.switchFromToFrame(currFrame, g_currFrame);
}
 
this.switchFromToFrame =  function(currFrame, toFrame)
{
     if (g_InTransition == 1)
     {
         self.stopAll();
     }
g_InTransition = 1;
self.startTransitionTimer();
     jqCS613207("#comSFrameSek613207_"+currFrame+"").css("z-index", 1);
     jqCS613207("#comSFrameSek613207_"+toFrame+"").css("z-index", 2);
     jqCS613207("#comSFrameSek613207_"+toFrame+"").hide().fadeIn(1350, function() { 
if (g_microID !=objcomSlider613207.getCurrMicroID()){return false;};jqCS613207("#comSFrame613207_"+currFrame).hide(); g_InTransition = 0;
 } ); 
  self.setNavStyle(currFrame, '000000','FFFFFF',1, 0);  self.setNavStyle(toFrame, '000000','FFFFFF',1, 1);     jqCS613207("#comSFrame613207_"+toFrame).show(1, function(){  });
     
     
     
     
}
this.startTransitionTimer = function()
{
  self.targetClearTimeouts(); g_TransitionTimeoutRef = window.setTimeout(function() {objcomSlider613207.onTransitionTimeout(g_microID)}, g_CycleTimeout*1000);
}
this.onTransitionTimeout = function(microID)
{
   if (g_microID != microID) { return false; }
     self.switchFrame();
}
this.initFrame = function()
{
g_currFrame = 0;
self.startTransitionTimer();
     jqCS613207("#comSFrameSek613207_"+g_currFrame+"").hide().fadeIn(1350);
  jqCS613207("#comSFrame613207_"+g_currFrame).show(1, function(){if (g_microID !=objcomSlider613207.getCurrMicroID()){return false;};self.setNavStyle(g_currFrame, '000000','FFFFFF',1, 1);     });
  return true;
}

					this.scriptLoaded = function()
					{
				   jqCS613207 = jQuery613207.noConflict(false);jqCS613207("#comslider_in_point_613207").html('<div id="comSWrapper613207_" name="comSWrapper613207_" style="display: inline-block; text-align: center; border:0px; width:1000px; height:500px; position: relative; top: 0px; left: 0px;"><div id="comSWrapper613207_" name="comSWrapper613207_" style="overflow:hidden;background:#000000;border:0px; width:1000px; height:500px; "><div id="comSFrameWrapper613207_" name="comSFrameWrapper613207_" style="position: absolute; top: 0px; left: 0px;"><div id="comSFrame613207_0" name="comSFrame613207_0" style="position:absolute; top:0px; left:0px; width:1000px; height:500px;"><div id="comSFrameSek613207_0" name="comSFrameSek613207_0" style="position:absolute; overflow:hidden; top:0px; left:0px; width:1000px; height:500px;"><div id="comSImg613207_0" name="comSImg613207_0" style="position:absolute; overflow:hidden; top:0px; left:0px; width:1000px; height:500px;"><img style="border:0px; width:752px; height:500px;"></img></div></div></div><div id="comSFrame613207_1" name="comSFrame613207_1" style="position:absolute; top:0px; left:0px; width:1000px; height:500px;"><div id="comSFrameSek613207_1" name="comSFrameSek613207_1" style="position:absolute; overflow:hidden; top:0px; left:0px; width:1000px; height:500px;"><div id="comSImg613207_1" name="comSImg613207_1" style="position:absolute; overflow:hidden; top:0px; left:0px; width:1000px; height:500px;"><img style="border:0px; width:914px; height:500px;"></img></div></div></div><div id="comSFrame613207_2" name="comSFrame613207_2" style="position:absolute; top:0px; left:0px; width:1000px; height:500px;"><div id="comSFrameSek613207_2" name="comSFrameSek613207_2" style="position:absolute; overflow:hidden; top:0px; left:0px; width:1000px; height:500px;"><div id="comSImg613207_2" name="comSImg613207_2" style="position:absolute; overflow:hidden; top:0px; left:0px; width:1000px; height:500px;"><img style="border:0px; width:754px; height:500px;"></img></div></div></div></div><a name="0" style="cursor:pointer; text-decoration:none !important; font-size:36px;" href=""><div id="comSNavigation613207_0" name="comSNavigation613207_0" style="margin-left:-1px; margin-top:-1px; border: 1px solid #FFFFFF; position:absolute; height:46px; width:70px; top:8px; left:920px; z-index: 5; text-align: center; vertical-align:bottom;  color: #FFFFFF;background: #000000; "><div id="height_workaround" style="font-size:1px;line-height:0;height:46px;">&nbsp;<img style="position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBullet613207_0" name="comImgBullet613207_0" src="comslider613207/imgnav/1504142141026052.jpg?timstamp=1429041826" /><img style="display: none; position: absolute; position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBulletcurr613207_0" name="comImgBulletcurr613207_0" src="comslider613207/imgnav/1504142141026052.jpg?timstamp=1429041826" /></div></div></a><a name="1" style="cursor:pointer; text-decoration:none !important; font-size:30px;" href=""><div id="comSNavigation613207_1" name="comSNavigation613207_1" style="margin-left:-1px; margin-top:-1px; border: 1px solid #FFFFFF; position:absolute; height:38px; width:70px; top:62px; left:920px; z-index: 5; text-align: center; vertical-align:bottom;  color: #FFFFFF;background: #000000; "><div id="height_workaround" style="font-size:1px;line-height:0;height:38px;">&nbsp;<img style="position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBullet613207_1" name="comImgBullet613207_1" src="comslider613207/imgnav/1504142144345851.jpg?timstamp=1429041826" /><img style="display: none; position: absolute; position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBulletcurr613207_1" name="comImgBulletcurr613207_1" src="comslider613207/imgnav/1504142144345851.jpg?timstamp=1429041826" /></div></div></a><a name="2" style="cursor:pointer; text-decoration:none !important; font-size:36px;" href=""><div id="comSNavigation613207_2" name="comSNavigation613207_2" style="margin-left:-1px; margin-top:-1px; border: 1px solid #FFFFFF; position:absolute; height:46px; width:70px; top:108px; left:920px; z-index: 5; text-align: center; vertical-align:bottom;  color: #FFFFFF;background: #000000; "><div id="height_workaround" style="font-size:1px;line-height:0;height:46px;">&nbsp;<img style="position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBullet613207_2" name="comImgBullet613207_2" src="comslider613207/imgnav/1504142144516661.jpg?timstamp=1429041826" /><img style="display: none; position: absolute; position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBulletcurr613207_2" name="comImgBulletcurr613207_2" src="comslider613207/imgnav/1504142144516661.jpg?timstamp=1429041826" /></div></div></a></div><div id="comSNavigationControl613207__back" name="comSNavigationControl613207__back" style="display: none; cursor: pointer; margin: 0px; margin-left:0px; border: 0px; position:absolute; height:48px; width:44px; top:226px; left:0px; z-index: 6; text-align: center; vertical-align:bottom;  background-color: transparent; "><img class="def" style="position: absolute; top: 0px; left: 0px; border: 0px;" src="comslider613207/imgnavctl/defback.png?1429041825" /><img class="hover" style="position: absolute; top: 0px; left: 0px; display:none; border: 0px;" src="comslider613207/imgnavctl/defbackhover.png?1429041825" /></div><script type="text/javascript"> jqCS613207("#comSNavigationControl613207__back").bind(\'mouseenter\', function() {  jqCS613207(this).css(\'background-color\', \'transparent\'); jqCS613207("#comSNavigationControl613207__back img.hover").show(); jqCS613207("#comSNavigationControl613207__back img.def").hide(); });</script><script type="text/javascript"> jqCS613207("#comSNavigationControl613207__back").bind(\'mouseleave\', function() {  jqCS613207(this).css(\'background-color\', \'transparent\'); jqCS613207("#comSNavigationControl613207__back img.def").show();  jqCS613207("#comSNavigationControl613207__back img.hover").hide(); });</script><script type="text/javascript"> jqCS613207("#comSNavigationControl613207__back").bind(\'click\', function() { objcomSlider613207.switchFramePrev(); });</script><div id="comSNavigationControl613207__forward" name="comSNavigationControl613207__forward" style="display: none; cursor: pointer; margin: 0px; margin-left:0px; border: 0px; position:absolute; height:48px; width:44px; top:226px; left:956px; z-index: 6; text-align: center; vertical-align:bottom; background-color: transparent; "><img class="def" style="position: absolute; top: 0px; left: 0px; border: 0px;" src="comslider613207/imgnavctl/defforward.png?1429041825" /><img class="hover" style="position: absolute; top: 0px; left: 0px; display:none; border: 0px;" src="comslider613207/imgnavctl/defforwardhover.png?1429041825" /></div><script type="text/javascript"> jqCS613207("#comSNavigationControl613207__forward").bind(\'mouseenter\', function() {  jqCS613207(this).css(\'background-color\', \'transparent\'); jqCS613207("#comSNavigationControl613207__forward img.hover").show(); jqCS613207("#comSNavigationControl613207__forward img.def").hide(); });</script><script type="text/javascript"> jqCS613207("#comSNavigationControl613207__forward").bind(\'mouseleave\', function() {  jqCS613207(this).css(\'background-color\', \'transparent\'); jqCS613207("#comSNavigationControl613207__forward img.def").show();  jqCS613207("#comSNavigationControl613207__forward img.hover").hide(); });</script><script type="text/javascript"> jqCS613207("#comSNavigationControl613207__forward").bind(\'click\', function() { objcomSlider613207.switchFrame(); });</script><script type="text/javascript">jqCS613207("#comSWrapper613207_").bind(\'mouseenter\', function() { jqCS613207("#comSNavigationControl613207__back").fadeIn("fast");jqCS613207("#comSNavigationControl613207__forward").fadeIn("fast"); });</script><script type="text/javascript">jqCS613207("#comSWrapper613207_").bind(\'mouseleave\', function() { jqCS613207("#comSNavigationControl613207__back").fadeOut("fast");jqCS613207("#comSNavigationControl613207__forward").fadeOut("fast"); });</script></div>');
                    jqCS613207("#comslider_in_point_613207 a").bind('click',  function() { if ((this.name.length > 0) && (isNaN(this.name) == false)) {  self.switchToFrame(parseInt(this.name)); return false;} });
                self.comSLoadImgInFrame("0", "comslider613207/img/1504142141026052.jpg?1429041825");
jqCS613207("#comSFrame613207_0").hide();
self.comSLoadImgInFrame("1", "comslider613207/img/1504142144345851.jpg?1429041825");
jqCS613207("#comSFrame613207_1").hide();
self.comSLoadImgInFrame("2", "comslider613207/img/1504142144516661.jpg?1429041825");
jqCS613207("#comSFrame613207_2").hide();
jqCS613207("#comSFrame613207_2").hide();
self.initFrame();

}
var g_CSIncludes = new Array();
var g_CSLoading = false;
var g_CSCurrIdx = 0; 
 this.include = function(src, last) 
                {
                    if (src != '')
                    {				
                            var tmpInclude = Array();
                            tmpInclude[0] = src;
                            tmpInclude[1] = last;					
                            //
                            g_CSIncludes[g_CSIncludes.length] = tmpInclude;
                    }            
                    if ((g_CSLoading == false) && (g_CSCurrIdx < g_CSIncludes.length))
                    {


                            var oScript = null;
                            if (g_CSIncludes[g_CSCurrIdx][0].split('.').pop() == 'css')
                            {
                                oScript = document.createElement('link');
                                oScript.href = g_CSIncludes[g_CSCurrIdx][0];
                                oScript.type = 'text/css';
                                oScript.rel = 'stylesheet';

                                oScript.onloadDone = true; 
                                g_CSLoading = false;
                                g_CSCurrIdx++;								
                                if (g_CSIncludes[g_CSCurrIdx-1][1] == true) 
                                        self.scriptLoaded(); 
                                else
                                        self.include('', false);
                            }
                            else
                            {
                                oScript = document.createElement('script');
                                oScript.src = g_CSIncludes[g_CSCurrIdx][0];
                                oScript.type = 'text/javascript';

                                //oScript.onload = scriptLoaded;
                                oScript.onload = function() 
                                { 
                                        if ( ! oScript.onloadDone ) 
                                        {
                                                oScript.onloadDone = true; 
                                                g_CSLoading = false;
                                                g_CSCurrIdx++;								
                                                if (g_CSIncludes[g_CSCurrIdx-1][1] == true) 
                                                        self.scriptLoaded(); 
                                                else
                                                        self.include('', false);
                                        }
                                };
                                oScript.onreadystatechange = function() 
                                { 
                                        if ( ( "loaded" === oScript.readyState || "complete" === oScript.readyState ) && ! oScript.onloadDone ) 
                                        {
                                                oScript.onloadDone = true;
                                                g_CSLoading = false;	
                                                g_CSCurrIdx++;
                                                if (g_CSIncludes[g_CSCurrIdx-1][1] == true) 
                                                        self.scriptLoaded(); 
                                                else
                                                        self.include('', false);
                                        }
                                }
                                
                            }
                            //
                            document.getElementsByTagName("head").item(0).appendChild(oScript);
                            //
                            g_CSLoading = true;
                    }

                }
                

}
objcomSlider613207 = new comSlider613207();
objcomSlider613207.include('comslider613207/js/helpers.js', false);
objcomSlider613207.include('comslider613207/js/jquery-1.10.1.js', false);
objcomSlider613207.include('comslider613207/js/jquery-ui-1.10.3.effects.js', true);
