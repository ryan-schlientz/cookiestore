<?php
session_start();
require_once 'userheader.php';
html_header("Sign In");
echo"<p>User Log In</p>";

		
echo <<<_END
<div class="checkout">
 <form action="userlogin.php" onsubmit="return allValid()" method="POST">
Email:<br>
<input type="text" id="nameId" name="username" value="">
<label id="eMName"></label><br>
Password:<br>
<input type="Password" id="pwdId" name="pwd" value="">
<label id="eMPwd"></label>
<br>
<br>
<input type="submit" value="Log In"><br>
</form>
</div>
_END;

foot();
?>
<script>
validate();
</script>
