/**
 * 
 */

function validate()
{

isValidPwd=true;
idPwd=document.getElementById("pwdId");
idPwd.onblur=function()
{
	var errorLabel2=document.getElementById("eMPwd");
	if (idPwd.value.length<5)
	{
	      errorLabel2.innerHTML="Password can not be less than 5 characters.";
	      isValidPwd=false;
	}	
	else
	{
		errorLabel2.innerHTML="";
		isValidPwd=true;
	}
	
}
}
function allValid()
{
	if(isValidPwd)
		return true;
	else
		return false;
}

function validateSignUp()
{
	isValidPass=true;
	isValidPass2=true;
	idPass=document.getElementById("passId");	
	idPass.onblur=function()
	{
		var errorLabel2=document.getElementById("eMPass");
		if (idPass.value.length<5)
		{
		      errorLabel2.innerHTML="Password can not be less than 5 characters.";
		      isValidPass=false;
		}	
		else
		{
			errorLabel2.innerHTML="";
			isValidPass=true;
		}
		
	}
	
	idPass2=document.getElementById("passId2");
	idPass2.onblur=function()
	{
		var errorLabel3=document.getElementById("eMPass2");
		if (idPass2.value==idPass.value)
		{
		      errorLabel3.innerHTML="";
		      isValidPass2=true;
		}	
		else 
		{
			errorLabel3.innerHTML="Passwords don't match. Type them again please.";
			isValidPass2=false;
		}
		
	}
	
}


function allValidSignUp()
{
	if(isValidPass && isValidPass2)
		return true;
	else
		return false;
}

