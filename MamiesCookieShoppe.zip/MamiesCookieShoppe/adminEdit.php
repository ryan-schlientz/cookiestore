<?php
require_once 'login.php';
require_once 'userheader.php';
session_start();

if(isset($_SESSION['admin']))
{
adminhtml_header("Edit Cookies");
//selects info for all pizzas.
$query = "SELECT cookieID, cookieName, price, imageName, display FROM cookies";

$result = mysql_query($query);
if(!$result) die("failed.".mysql_error());


//additional tid bit to prevent cookeID from exceeding max number of cookies.
$queryRowCount = "SELECT cookieID FROM cookies";
$resultRowCount = mysql_query($queryRowCount);
$numRows = mysql_num_rows($resultRowCount);

$rows = mysql_num_rows($result);
echo <<<_END
<table>
<tr>
<th>Cookie ID</th>
<th>Cookie Name</th>
<th>Price</th>
<th>Image</th>
<th>Display<br>(1 for Yes; 0 for No)</th>
</tr>
_END;

for($i = 0; $i < $rows; $i++)		//prints all pizzas with information in a table.
{
	$row = mysql_fetch_row($result);
	echo <<<_END
	<tr>
	<td>$row[0]</td>
	<td>$row[1]</td>
	<td>$row[2]</td>
	<td><img src="./images/$row[3]" width="109" height="119" alt="$row[1]" /></td>
	<td>$row[4]</td>
	
	</tr>
_END;
}
echo "</table>";
//form allows you to select cookie based on cookieID to change its information
echo <<<_END
<p>
<form name="form1" method="post" action="adminChange.php">
<p>Cookie ID: 
  <input name="cookieID" type="number" value="1" min="1" max="$numRows" size="10"/>
  <input name="change" type="submit" value="Change" /></p>
</form>
</p>
_END;

adminfoot();
}
else {
	adminDeny();
}
?>