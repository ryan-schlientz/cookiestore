<?php
session_start();
require_once 'userheader.php';
html_header("Our Location");
echo <<<_END
<h2>We're Moving!</h2>
<p class="text">Mamie's Cookie Shoppe is currently in the process of finding a new home. 
		Stay tuned for updates about our next location. 
		For now you can find us at:</p>
		<p class="text"> I-75 Flea Market <br>400 Direct Connection Drive (East Entrance) <br>Rossville, GA 30741</p>

		<div id="map-canvas"></div>
_END;
foot();
?>

<script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAbUSnBH96wzuirQEcEkEn7dl7z8QU8wZk">
</script>
<script>
	function initialize() {
        var mapOptions = {
          center: {lat: 34.983354, lng: -85.202372},
          zoom: 15
        };
        
        var map = new google.maps.Map(document.getElementById('map-canvas'),
            mapOptions);

        var marker = new google.maps.Marker({
  	      position: {lat: 34.983354, lng: -85.202372},
  	      map: map,
  	      title: 'Find Us Here!'
  	  });
      }

	google.maps.event.addDomListener(window, 'load', initialize);
</script>