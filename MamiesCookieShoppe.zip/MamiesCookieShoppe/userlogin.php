<?php
session_start();
require_once 'userheader.php';
require_once 'login.php';
$validlogin=true;

if (isset($_POST['username'])) $user = sanitizeString($_POST['username']);
if (isset($_POST['pwd'])) $pass = sanitizeString($_POST['pwd']);

$query="SELECT * FROM customer WHERE email= '$user' AND pwd=PASSWORD('$pass')";
$result = mysql_query($query);
if(!$result) die ("Access Failed".mysql_error());
$rows = mysql_num_rows($result);
if($rows==1)
{
	$row=mysql_fetch_row($result);
	$_SESSION['username']=$row[1].", ".$row[2];
	$_SESSION['custID']=$row[0];
	$validlogin=true;
	
}
else
{
	$validlogin=false;
}
html_header("User Log In");
if(!($validlogin))
{
echo <<<_END
<p> Log in failed. Invalid username/password combination. Please try again. <a href="signIn.php">Sign In</a></p>
_END;

}
else
{
echo "<p> Log in successful!</p>";	
}
foot();
?>