<?php
require_once 'login.php';
require_once 'userheader.php';
session_start();

if(isset($_SESSION['admin']))
{
adminhtml_header("Change Pizza Info");
echo <<<_END
<p>
		Change the information for this cookie.
</p>
_END;

//obtained from adminEdit
$cID = $_POST['cookieID'];

//query obtains your selected cookie's information
$query = "SELECT cookieName, price, imageName, display FROM cookies WHERE cookieID='$cID'";
$result = mysql_query($query);
$row = mysql_fetch_row($result);

//this form allows you to change the information.
echo <<<_END
<form name="form1" method="post" action="adminChangeConfirm.php">
<p>CookieID: $cID</p>
	<p>Cookie Name: 
  	<input name="cookieName" type="text" value="$row[0]" /></p>
  	<p>Price: 
  	<input name="price" type="number" value="$row[1]" step="0.01" min="0"/></p>
  	<p>Image File Name: 
  	<input name="imageName" type="text" value="$row[2]" /></p>
  	<p>Display: (1 for Yes; 0 for No) 
  	<input name="display" type="number" value="$row[3]" step="1" min="0" max="1"/></p>
  	
  	<p><input name="update" type="submit" value="Update" /></p>
  	<input name="cookieID" type="hidden" value="$cID" />
</form>
_END;

adminfoot();
}
else
	adminDeny();
?>