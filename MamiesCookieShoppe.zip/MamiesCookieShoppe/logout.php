<?php
/*This page is opened when the user clicks log out. It destroys the session.*/
session_start();
$_SESSION['username']=null;
session_destroy();
require_once 'userheader.php';
html_header('Logged Out');

echo "<p>You have successfully logged out. </p>";
foot();
?>