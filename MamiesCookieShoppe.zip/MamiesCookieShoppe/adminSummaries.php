
<?php 
session_start();
require_once 'userheader.php';
require_once 'login.php';


if(isset($_SESSION['admin']))
{
adminhtml_header("Summary Page");
echo "<h2>Daily Order Summary</h2>";

if(isset($_GET['signed']))		//if you have selected a date, then the daily summary will be shown
{
	$orderDate = $_GET['day'];	//retrieves date selected.
	$query = "SELECT cookieName, quantity, quantity*price 
			  FROM cookies, orders, items
			  WHERE orders.orderDate BETWEEN '$orderDate' AND DATE_ADD('$orderDate', INTERVAL 1 DAY)
			  AND cookies.cookieID = items.cookieID AND orders.orderID=items.orderID
			  GROUP BY cookieName"; 
	//query selects sums and names from pizza table on that date.

$result = mysql_query($query);
if(!$result) die("failed.".mysql_error());

$rows = mysql_num_rows($result);
echo "<p>Date: " . $orderDate . "<p/>";
echo "<table>";
$sales = 0;
for($i = 0; $i < $rows; $i++)		//prints every pizza type sold with quantity
{
	$row = mysql_fetch_row($result);
	if ($i%2 == 0)
		echo "<tr>"; //start a new row in table - 4 items per row
	echo "<td>";
	echo <<<_END
	<p class="text">Cookie: $row[0]<br/>
		Number Sold: $row[1]<br/><br/><p>
_END;
	$sales += $row[2];
	echo "</td>";
	if ($i%2 == 1) //if on 4th item, end row
		echo "</tr>";
	elseif ($i == $rows - 1) //if end of loop, end row
	echo "</tr>";
}
	echo "</table>";
	//prints total sales.
	echo <<<_END
	<p class="text">Total Sales today: $$sales</p>
_END;
}
else					//if you have not picked a date, then you must do so.
{
	echo <<<_END
	<p>Pick a date to view the total sales for each cookie.</p>
_END;
	datePick();
}
adminfoot();
}
else {
	adminDeny();
}

function datePick()		//simply prints a form to select a date.
{
	echo <<<_END
<form name="form5" method="get" action="adminSummaries.php?signed=1">
  <p>Date:
    <input type="date" name="day"/></p>
  <p>
    <input name="signed" type="submit"  value="Get Orders"/></p>
</form>
_END;
}
?>