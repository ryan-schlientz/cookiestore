<?php

$h="198.71.225.59:3306";
$db="cookiestore";
$username="kirtan2";
$pwd="kirtan12";
$db_server =mysql_connect($h,$username,$pwd);
if(!$db_server) die("Unable to connect".mysql_error());

mysql_select_db($db);
?>