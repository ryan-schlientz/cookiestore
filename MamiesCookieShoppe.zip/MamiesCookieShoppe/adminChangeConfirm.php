<?php
require_once 'login.php';
require_once 'userheader.php';
session_start();

if(isset($_SESSION['admin']))
{

adminhtml_header("Confirm Changes");

//obtained from adminChange
$cID = $_POST['cookieID'];
$price = $_POST['price'];
$cName = $_POST['cookieName'];
$imageName = $_POST['imageName'];
$display = $_POST['display'];

//query updates the database with new information
$sql = "UPDATE cookies SET price='$price',cookieName='$cName',imageName='$imageName', display='$display' WHERE cookieID='$cID'";
$resultSql = mysql_query($sql);

if(!$resultSql)	//prints message for invalid input.
{
	echo "Information was invalid. Please try to change the information again.";
	echo <<<_END
<p>
<a href="adminChange.php" title="adminChange">Back</a>
</p>
_END;
}
else		//prints success statement
{
	echo <<<_END
	<p>You have successfully Updated the information!</p>
	<p>
	<a href="adminEdit.php" title="adminEdit">To Edit Page</a>
	</p>
_END;
}


adminfoot();
}
else 
	adminDeny();
?>