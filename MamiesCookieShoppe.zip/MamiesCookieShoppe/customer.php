<?php
session_start();
require_once 'userheader.php';
html_header("Customer Service");
echo<<<_END
<p>To contact us with any questions please call (###) ###-####.</p>
_END;
foot();
?>