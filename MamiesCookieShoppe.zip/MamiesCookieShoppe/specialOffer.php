<?php
session_start();
require_once 'userheader.php';
html_header("Special Offers");
echo <<<_END
<p class="text">Special Offer: May 9th ONLY! Get two half dozens of your flavor choice along with a 
		Mother's Day Bouqet of 4 Cookies on a Stick for only $10.</p>
_END;
foot();
?>