<?php
session_start();
require_once 'userheader.php';
html_header("Rewards for our Customers");
echo <<<_END
<p class="text">Come by Mamie's Cookie Shoppe anytime and ask about our rewards card. 
		Bring your card to the Shoppe and we will stamp it for every dozen you buy. 
		Once you collect 10 stamps, get a free dozen of your choice.</p>
_END;
foot();
?>