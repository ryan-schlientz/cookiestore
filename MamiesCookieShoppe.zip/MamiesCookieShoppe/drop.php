<?php
session_start();
require_once 'userheader.php';
require_once 'login.php';
html_header("Remove Item");
//begin page content
if (isset($_SESSION['custID']))
	$custID = $_SESSION['custID'];

//get number of cookie types
$query = "SELECT cookieID FROM cookies;";
$result = mysql_query($query);
if(!$result) die ("Query failed. ".mysql_error());
$numRows = mysql_num_rows($result); //number of rows = number of cookie types

//check which order is to be dropped (name of buttons are in format drop[cookieID])
//$i = cookieID because cookieID starts at 1
$cID = 0;
for ($i = 1; $i <= $numRows; $i++)
{
	if (isset($_POST["drop$i"]))
		$cID = $i;
}

//get order ID of order
$orderQuery = "SELECT orderID FROM temporders WHERE customerID=$custID;";
$orderResult = mysql_query($orderQuery);
if(!$orderResult) die ("Query failed. ".mysql_error());
$row = mysql_fetch_row($orderResult);
$orderID = $row[0];

//drop item from tempitems table
$deleteQuery = "DELETE FROM tempitems WHERE orderID=$orderID AND cookieID=$cID;";
$deleteResult = mysql_query($deleteQuery);
if (!$deleteResult) die ("Query failed. ".mysql_error());

//check to see if there are items left for the order; if so, update order total; if not, drop order
$itemQuery = "SELECT quantity, price FROM tempitems, cookies WHERE orderID = $orderID AND tempitems.cookieID = cookies.cookieID;";
$itemResult = mysql_query($itemQuery);
if(!$itemResult) die ("Query failed. ".mysql_error());
$numItems = mysql_num_rows($itemResult);
if ($numItems > 0)
{
	$total = 0;
	for ($j = 0; $j < $numItems; $j++)
	{
		$itemRow = mysql_fetch_row($itemResult);
		$total = $total + ($itemRow[0] * $itemRow[1]);
		$updateQuery = "UPDATE temporders SET total = $total WHERE customerID = $custID;";
		$updateResult = mysql_query($updateQuery);
		if (!$updateResult) die ("Query failed. ".mysql_error());
	}
}
else
{
	$deleteQuery2 = "DELETE FROM temporders WHERE customerID = $custID;";
	$deleteResult2 = mysql_query($deleteQuery2);
	if (!$deleteResult2) die ("Query failed. ".mysql_error());
}

echo "<p>Item removed successfully.</p>";
echo '<p><a href="myorder.php">Return to cart</a></p>';
//end page content
foot();
?>