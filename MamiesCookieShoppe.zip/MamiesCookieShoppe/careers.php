<?php
session_start();
require_once 'userheader.php';
html_header("Careers");
echo<<<_END
<p>Mamie's Cookie Shoppe is currently not hiring, however, 
		we are in the process of relocating and potentially expanding our Cookie Shoppe. Please check back with us in the future.</p>

_END;
foot();
?>