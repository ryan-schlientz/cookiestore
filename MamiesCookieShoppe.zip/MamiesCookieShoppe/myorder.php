<?php
session_start();
require_once 'userheader.php';
require_once 'login.php';
html_header("Your Cart");
//begin page content
if (isset($_SESSION['custID']))
	$custID = $_SESSION['custID'];

//get number of cookie types
$numQuery = "SELECT cookieID FROM cookies;";
$numResult = mysql_query($numQuery);
if(!$numResult) die ("Query failed. ".mysql_error());
$numCookies = mysql_num_rows($numResult); //number of rows = number of cookie types

//insert orders into temporders table - placed into orders table upon checkout
for ($i = 0; $i < $numCookies; $i++)
{
	//check that the cookieID, quantity, price from order form exist
	$quant = 0;
	if (isset($_POST["cookieID_$i"]))
		$cID = $_POST["cookieID_$i"];
	if (isset($_POST["quantity_$i"]))
	{
		$quant = $_POST["quantity_$i"];
		$_POST["quantity_$i"] = 0; //return quantity to zero to avoid duplicating order if page is reloaded
	}
	if (isset($_POST["price_$i"]))
		$price = $_POST["price_$i"];
	
	if ($quant > 0) //if there is an order for the cookie type
	{
		//check to see if the cookieID exists already in the table for the customer
		$idExists = FALSE;
		$existQuery = "SELECT tempitems.quantity FROM tempitems, temporders WHERE temporders.customerID=$custID AND tempitems.cookieID=$cID AND tempitems.orderID = temporders.orderID;";
		$existResult = mysql_query($existQuery);
		if(!$existResult) die ("Query failed. ".mysql_error());
		if (mysql_num_rows($existResult) > 0)
			$idExists = TRUE;
		
		//check to see if an order exists in tempOrders for the customer; if so, get orderID
		$orderExists = FALSE;
		$orderID = 0;
		$orderQuery = "SELECT orderID FROM temporders WHERE customerID=$custID;";
		$orderResult = mysql_query($orderQuery);
		if(!$orderResult) die ("Query failed. ".mysql_error());
		if (mysql_num_rows($orderResult) > 0)
		{
			$orderExists = TRUE;
			$orderRow = mysql_fetch_row($orderResult);
			$orderID = $orderRow[0];
		}

		//if an order exists for the customer, update that order
		if ($orderExists)
		{
			if ($idExists) //if the cookieID already exists for this customer, update existing tempitems
			{
				//update temporder total
				$total = $quant * $price;
				$query1 = "UPDATE temporders SET total = total + $total WHERE customerID = $custID;";
				$result1["$i"] = mysql_query($query1);
				if (!$result1["$i"]) die ("Query failed. ".mysql_error());
				//update tempitems quantity
				$query2 = "UPDATE tempitems INNER JOIN temporders ON temporders.orderID = tempitems.orderID SET tempitems.quantity = tempitems.quantity + $quant WHERE tempitems.cookieID = $cID AND temporders.customerID = $custID;";
				$result2["$i"] = mysql_query($query2);
				if (!$result2["$i"]) die ("Query failed. ".mysql_error());
			}
			else //otherwise, insert new tempitems
			{
				//insert new tempitems
				$total = $quant * $price;
				$query1 = "INSERT INTO tempitems (orderID, cookieID, quantity) VALUES ($orderID, $cID, $quant);";
				$result1["$i"] = mysql_query($query1);
				if (!$result1["$i"]) die ("Query failed. ".mysql_error());
				//update temporder total
				$query2 = "UPDATE temporders SET total = total + $total WHERE customerID = $custID;";
				$result2["$i"] = mysql_query($query2);
				if (!$result2["$i"]) die ("Query failed. ".mysql_error());
			}
		}
		else //otherwise, insert new order
		{
			//insert new order
			$total = $quant * $price;
			$query1 = "INSERT INTO temporders (customerID, total) VALUES ($custID, $total);";
			$result1["$i"] = mysql_query($query1);
			if (!$result1["$i"]) die ("Query failed. ".mysql_error());
			//get orderID for new order
			$orderQuery2 = "SELECT orderID FROM temporders WHERE customerID = $custID";
			$orderResult2 = mysql_query($orderQuery2);
			if (!$orderResult2) die ("Query failed. ".mysql_error());
			$orderRow2 = mysql_fetch_row($orderResult2);
			$orderID = $orderRow2[0];
			//insert new tempitems
			$query2 = "INSERT INTO tempitems (orderID, cookieID, quantity) VALUES ($orderID, $cID, $quant);";
			$result2["$i"] = mysql_query($query2);
			if (!$result2["$i"]) die ("Query failed. ".mysql_error());
		}
	}
}

if(isset($_SESSION['custID']))
{
//Select cookieName, quantity, and cookieID of all entries by current customer
$query1 = "SELECT cookieName, quantity, tempitems.cookieID FROM cookies, tempitems, temporders WHERE cookies.cookieID = tempitems.cookieID AND tempitems.orderID = temporders.orderID AND customerID='$custID';";
//Select total price of all customer's orders
$query2 = "SELECT total FROM temporders WHERE customerID = '$custID';";

$result1 = mysql_query($query1);
if(!$result1) die ("Query failed. ".mysql_error());

$rows = mysql_num_rows($result1);

$result2 = mysql_query($query2);
if(!$result2) die ("Query failed. ".mysql_error());

//Display all pending orders in table - also a form for dropping orders
echo<<<_END
	<form id="form0" name="form0" method="post" action="drop.php">
	<table align="center">
		<caption class="text">Pending Orders</caption>
_END;
echo "<tr>";
echo "<th>Cookie Type</th>";
echo "<th>Quantity</th>";
echo "<th>Remove Order</th>";
echo "</tr>";
for ($i = 1; $i <= $rows; $i++)
{
$row = mysql_fetch_row($result1);
echo "<tr>";
		echo "<td>$row[0]</td><td>$row[1]</td><td style='text-align:center'>";
		//cookieID is used for name of button e.g. drop1, drop2- this is used to know what cookieID to drop in drop.php
		echo "<input name='drop$row[2]' type='submit' id='button' value='Remove Order'/>";
		echo "</td></tr>";
	}
		echo "</table>";
				$row2 = mysql_fetch_row($result2);
				if ($row2[0] == 0)
					$totalPrice = "N/A";
				else
					$totalPrice = "$".$row2[0]; 
				echo<<<_END
	<p style="text-align:center">Total price: $totalPrice</p>
	</form>
	<form id="form1" name="form1" method="post" action="checkOut.php">
	<p style="text-align:center"><input name="checkout" type="submit" id="button" value="Check Out" /></p>
	</form>
	<p style="text-align:center">Warning: Checking out will submit ALL of your currently pending orders!</p>
_END;
}
else
	echo "<p>You have no order right now.</p>";
//end page content
foot();
?>