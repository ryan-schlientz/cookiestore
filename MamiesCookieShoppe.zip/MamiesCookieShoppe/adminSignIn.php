<?php
session_start();
require_once 'userheader.php';
html_header("Admin Login");
		
if(isset($_SESSION['username']))
{
	echo <<<_END
	<p>You must sign out to continue to the admin section. <a href="logout.php">Log Out</a></p>		
_END;
}
else
{
echo <<<_END
<div class="checkout">
 <form action="adminlogin.php" onsubmit="return allValid()" method="POST">
Admin Username:<br>
<input type="text" id="adminnameId" name="username" value="">
<label id="eMName"></label><br>
Admin Password:<br>
<input type="Password" id="adminpwdId" name="pwd" value="">
<label id="eMPwd"></label>
<br>
<br>
<input type="submit" value="Log In"><br>
</form>
</div>
_END;
}

foot();
?>
<script>
validate();
</script>
