<?php
session_start();
require_once 'userheader.php';
html_header("Sign Up Here");

signup();
foot();
?>