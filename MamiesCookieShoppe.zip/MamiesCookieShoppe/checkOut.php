<?php
session_start();
require_once 'userheader.php';
require_once 'login.php';
html_header("Check Out");
//begin page content
if (isset($_SESSION['custID']))
	$custID = $_SESSION['custID'];

//get information about customer's orders
$query0 = "SELECT cookieID, quantity, total, temporders.orderID FROM tempitems, temporders WHERE tempitems.orderID = temporders.orderID AND customerID=$custID;";
$result0 = mysql_query($query0);
if (!$result0) die ("Query failed. ".mysql_error());
$numResults = mysql_num_rows($result0);

$tempID = 0;
$orderID = 0;

for ($i = 0; $i < $numResults; $i++)
{
	//get information about order
	$currentRow = mysql_fetch_row($result0);
	$cID = $currentRow[0];
	$quant = $currentRow[1];
	//add new order to orders only if first iteration of loop
	if ($i == 0)
	{
		$total = $currentRow[2];
		$tempID = $currentRow[3]; //used to drop items from tempitems later
		$orderQuery = "INSERT INTO orders (customerID, total) VALUES ('$custID', $total);";
		$orderResult = mysql_query($orderQuery);
		if (!$orderResult) die ("Query failed. ".mysql_error());
		//get new orderID from orders table (most recent order of the customer)
		$idQuery = "SELECT orderID FROM orders WHERE customerID = $custID;";
		$idResult = mysql_query($idQuery);
		if (!$idResult) die ("Query failed. ".mysql_error());
		$orderID = mysql_fetch_row($idResult)[0];
	}
	//add items to "items" table, rather than "tempitems"
	$itemQuery = "INSERT INTO items (cookieID, quantity, orderID) VALUES ($cID, $quant, $orderID);";
	$itemResult["$i"] = mysql_query($itemQuery);
	if (!$itemResult["$i"]) die ("Query failed. ".mysql_error());
}

//drop all of customer's items from "tempitems" table (prevents duplicate orders if page is reloaded)
$deleteQuery1 = "DELETE FROM tempitems WHERE orderID=$tempID;";
$deleteResult1 = mysql_query($deleteQuery1);
if (!$deleteResult1) die ("Query failed. ".mysql_error());

//drop customer's order from "temporders" table
$deleteQuery2 = "DELETE FROM temporders WHERE customerID=$custID;";
$deleteResult2 = mysql_query($deleteQuery2);
if (!$deleteResult2) die ("Query failed. ".mysql_error());

echo "<p>Order placed successfully.</p>";
//end page content
foot();
?>