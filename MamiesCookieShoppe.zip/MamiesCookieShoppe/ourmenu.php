<?php
session_start();
require_once 'userheader.php';
require_once 'login.php';
html_header("Our Menu");
//begin page content
//retrieve cookie data from table
$query = "SELECT cookieID, cookieName, price, imageName FROM cookies WHERE display=1;";
$result = mysql_query($query);
if(!$result) die ("Query failed. ".mysql_error());

//display cookies in a table; have a form for ordering (if logged in)
if(isset($_SESSION['username']))
{
	$rows = mysql_num_rows($result);
	echo '<form id="form1" name="form1" method="post" action="myorder.php">';
	echo '<table align="center"><caption class="text">Menu</caption>';
	for ($i = 0; $i < $rows; $i++)
	{
		$row = mysql_fetch_row($result);
		if ($i%4 == 0)
			echo "<tr>"; //start a new row in table - 4 items per row
		echo "<td>";
		echo<<<_END
			<p>$row[1]</p>
			<p><img src="./images/$row[3]" width="109" height="119" alt="$row[1]" /></p>
			<p>price: $$row[2]<br>(By the Dozen)</p>
			
			<p>quantity: (boxes)
		    	<input name="quantity_$i" type="number" value="0" min="0" size="5" />
			</p>
				<!-- Hidden fields containing other information about cookies -->
		  		<input name="cookieID_$i" type="hidden" value="$row[0]"/>
		  		<input name="cookieName_$i" type="hidden" value="$row[1]"/>
		  		<input name="price_$i" type="hidden" value="$row[2]"/>
_END;
		echo "</td>";
		if ($i%4 == 3) //if on 4th item, end row
			echo "</tr>";
		elseif ($i == $rows - 1) //if end of loop, end row
		echo "</tr>";
	}
	echo "</table>";
	echo '<p align="center"><input name="button" type="submit" id="button" value="Add to Cart" /></p>';
	echo "</form>";
}
else //No form for ordering (if not logged in)
{
	echo "<p>Please sign in to place orders. Thank you.</p>";
	$rows = mysql_num_rows($result);
	echo '<table align="center"><caption class="text">Menu</caption>';
	for ($i = 0; $i < $rows; $i++)
	{
	$row = mysql_fetch_row($result);
	if ($i%4 == 0)
		echo "<tr>"; //start a new row in table - 4 items per row
	echo "<td>";
		echo<<<_END
			<p>$row[1]</p>
			<p><img src="./images/$row[3]" width="109" height="119" alt="$row[1]" /></p>
			<p>price: $$row[2]<br>(By the Dozen)</p>
_END;
		echo "</td>";
		if ($i%4 == 3) //if on 4th item, end row
			echo "</tr>";
		elseif ($i == $rows - 1) //if end of loop, end row
			echo "</tr>";
	}
	echo "</table>";
}
//end page content
foot();
?>