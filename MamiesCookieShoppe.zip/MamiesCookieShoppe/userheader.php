<?php

//This function has a code for a slideshow of cookies. This code has been downloaded from a wesbite www.comslider.com.
function html_header($title)
{
//all the style will go in mystyle.css file.	
echo<<<_END
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="./css/mystyle.css">
<link rel="shortcut icon" href="./images/cookieIcon.jpg">
<script type="text/javascript" src="js/myfnc.js"></script>
</head>
<title> $title</title>	
		
_END;
if(isset($_SESSION['username']))
{
	$username=$_SESSION['username'];
	echo <<<_END
	<a href="logout.php" class="logout">Logout</a><p class="cookie">You are logged in as $username</p>
_END;
}
echo <<<_END
<body>
<div id="header">
		<h1>
		<img src="./images/logo.jpg" />
		 <span class="title">Welcome to Mamie's Cookie Shoppe</span> <img src="./images/logo.jpg" />
		</h1>
</div>
<br>
		
<div align="center">
	<a href="index.php" class="button">Main</a>		
	<a href="about.php" class="button">About</a>
	<a href="ourmenu.php" class="button">Our Menu</a> 
	<a href="specialOffer.php" class="button">Special Offer</a>	
	<a href="rewards.php" class="button">Rewards</a>
	<a href="myOrder.php" class="button">Cart</a>				
		

_END;

if(!isset($_SESSION['username']))
{	
	echo <<<_END
	<a href="signIn.php" class="button">Sign In</a>
	<a href="SignUp.php" class="button">Sign Up</a>	
</div>				
_END;
}
else 
	echo "</div>";	

echo "<br>";
}
function sanitizeString($var)
{
	$var = stripslashes($var);
	$var = htmlentities($var);
	$var = strip_tags($var);
	return $var;
}

function foot()
{
	echo <<<_END
<div class="footer">
<p class="footstyle"><a class="foot" href="customer.php">Customer Service</a> <a class="foot" href="location.php">Our Location</a> 
			 <a class="foot" href="careers.php">Careers</a> <a class="foot" href="adminSignIn.php">Admin</a> </p>
</div>
_END;

}

function adminhtml_header($title)
{
	//all the style will go in mystyle.css file.
	echo<<<_END
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="./css/mystyle.css">
<script type="text/javascript" src="js/myfnc.js"></script>
</head>
<title> $title</title>

_END;
	if(isset($_SESSION['admin']))
{
	$admin=$_SESSION['admin'];
	echo <<<_END
	<a href="adminLogout.php" class="logout">Logout</a><p class="cookie">You are logged in as $admin</p>
_END;
echo <<<_END
<body>
<div id="header">
		<h1>Welcome To Our Cookie Store</h1>
</div>
<br>

<div align="center">
	<a href="adminSummaries.php" class="button">Summaries</a>
	<a href="adminEdit.php" class="button">Edit Cookies</a>
	</div>

_END;

}
echo "<br>";
}

function adminfoot()
{
	echo <<<_END
<div class="footer">
<p class="footstyle"><a class="foot" href="adminLogout.php">Leave Admin Section</a></p>
</div>
_END;

}

function adminDeny()
{
	html_header("Summary Page");
	echo <<<_END
	<p> You don't have proper access to this page. Please sign in again. <a href="adminSignIn.php">Admin Log In</a></p>
_END;
	foot();
}


function signup()
{
	echo <<<_END
<div class="checkout">
 <form action="signupvalidate.php" onsubmit="return allValidSignUp()" method ="post" >
Last name:<br>
<input type="text" name="lastname" size="20" required="required"><br>
First name:<br>
<input type="text" name="firstname" size="20" required="required"><br>
Email:<br>
<input type="text" name="email" size="30" required="required"><br>
Password:<br>
<input type="password" id ="passId" name="password" size="20" required="required"><br>
<label id="eMPass"></label><br>			
Confirm Password:<br>
<input type="password" id="passId2" name="confirmpassword" size="20" required="required"><br>
<label id="eMPass2"></label><br>			
<br>
<input type="submit" value="Sign Up" style="font-size:20px">
<button type="reset" style="font-size:20px" align="right">Reset</button>
</form>
</div>
<script>
	validateSignUp();
	</script>	
_END;
		
}